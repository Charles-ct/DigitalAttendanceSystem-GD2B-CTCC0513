import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.table.TableRowSorter;

public class Admin extends javax.swing.JFrame {
    private DefaultTableModel model;
    private JTextField searchField;  // Search field
    private JButton searchButton;    // Search button

    // Constructor that accepts the table model from the Student_Details window
    public Admin(DefaultTableModel model) {
        initComponents();
        this.model = model;

        // Set the received model to the table in Admin window
        attendanceTable.setModel(model);  // Use auto-generated 'attendanceTable'

        // Create and add search components
        searchField = new JTextField(20);  // Search field for input
        searchButton = new JButton("Search");  // Search button

        // Add the search field and button to the window
        JPanel searchPanel = new JPanel();
        searchPanel.add(new JLabel("Search by Name:"));
        searchPanel.add(searchField);
        searchPanel.add(searchButton);

        // Add the search panel to the frame (you might want to use a layout manager for better positioning)
        add(searchPanel, "North");

        // Add action listener to the search button
        searchButton.addActionListener(evt -> searchStudent());  // This triggers the search functionality when clicked
    }

    // Function to perform the search based on the Student Name and update the table
    private void searchStudent() {
        String query = searchField.getText().toLowerCase().trim();  // Get the search query from the JTextField

        // If the search query is empty, show all data again
        if (query.isEmpty()) {
            attendanceTable.setModel(model);  // Reset the table model to the original data (unfiltered)
            return;
        }

        // Create a new model for filtered data (only rows that match the search query)
        DefaultTableModel filteredModel = new DefaultTableModel();

        // Add the column headers to the filtered model
        for (int col = 0; col < model.getColumnCount(); col++) {
            filteredModel.addColumn(model.getColumnName(col));
        }

        // Flag to check if any student was found
        boolean found = false;

        // Loop through the rows and find matching student names
        for (int row = 0; row < model.getRowCount(); row++) {
            // Assuming the student name is in the first column (index 0), modify this if the name is in another column
            String studentName = model.getValueAt(row, 0).toString().toLowerCase();  // Get the student name from the first column

            // Check if the student's name contains the search query (case-insensitive)
            if (studentName.contains(query)) {
                // If a match is found, add the row to the filtered model
                Object[] rowData = new Object[model.getColumnCount()];
                for (int col = 0; col < model.getColumnCount(); col++) {
                    rowData[col] = model.getValueAt(row, col);
                }
                filteredModel.addRow(rowData);
                found = true;
            }
        }

        // Set the table model to the filtered data
        attendanceTable.setModel(filteredModel);

        // Show a message if no matches were found
        if (!found) {
            JOptionPane.showMessageDialog(this, "No students found matching the search criteria.");
        }
    }

    // Save the modified table data to the CSV file
    private void saveTableData() {
        try {
            FileWriter writer = new FileWriter("attendance_data.csv");

            // Write table headers
            DefaultTableModel model = (DefaultTableModel) attendanceTable.getModel();
            for (int col = 0; col < model.getColumnCount(); col++) {
                writer.write(model.getColumnName(col) + ",");
            }
            writer.write("\n");  // New line after column names

            // Write table rows
            for (int row = 0; row < model.getRowCount(); row++) {
                for (int col = 0; col < model.getColumnCount(); col++) {
                    writer.write(model.getValueAt(row, col).toString() + ",");
                }
                writer.write("\n");
            }

            writer.close();
            JOptionPane.showMessageDialog(this, "Data saved successfully.");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error saving data: " + ex.getMessage());
        }
    }

    // Action handler for the save button
    private void saveButtonActionPerformed(java.awt.event.ActionEvent evt) {
        // Save the current table data to the file
        saveTableData();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        attendanceTable = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        Search_Bar = new javax.swing.JTextField();
        Search = new java.awt.Button();
        button1 = new java.awt.Button();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(128, 0, 0));

        attendanceTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "First Name", "Last Name", "Student ID", "Address", "Date ", "Time"
            }
        ));
        attendanceTable.setColumnSelectionAllowed(true);
        attendanceTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(attendanceTable);
        attendanceTable.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BPSU LOGO.png"))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Daily Attendance");

        jLabel3.setFont(new java.awt.Font("Arial", 0, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Search");

        Search_Bar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Search_BarActionPerformed(evt);
            }
        });
        Search_Bar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                Search_BarKeyReleased(evt);
            }
        });

        Search.setLabel("Search");
        Search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchActionPerformed(evt);
            }
        });

        button1.setLabel("SAVE");
        button1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(92, 92, 92)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(Search_Bar, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(30, 30, 30)
                                .addComponent(Search, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 67, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 620, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(button1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(67, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Search_Bar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Search, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel1)
                        .addGap(72, 72, 72))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(78, 78, 78)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 419, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(button1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(34, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Search_BarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Search_BarActionPerformed
  

    }//GEN-LAST:event_Search_BarActionPerformed

    private void SearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchActionPerformed
       DefaultTableModel ob = (DefaultTableModel) attendanceTable.getModel();
       TableRowSorter<DefaultTableModel> obj=new TableRowSorter<>(ob);
       attendanceTable.setRowSorter(obj);
       obj.setRowFilter(RowFilter.regexFilter(Search_Bar.getText()));
               
    }//GEN-LAST:event_SearchActionPerformed

    private void Search_BarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Search_BarKeyReleased
       DefaultTableModel ob = (DefaultTableModel) attendanceTable.getModel();
       TableRowSorter<DefaultTableModel> obj=new TableRowSorter<>(ob);
       attendanceTable.setRowSorter(obj);
       obj.setRowFilter(RowFilter.regexFilter(Search_Bar.getText()));
    }//GEN-LAST:event_Search_BarKeyReleased

    private void button1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button1ActionPerformed
     this.dispose();
    }//GEN-LAST:event_button1ActionPerformed

 
   public static void main(String args[]) {
        
        DefaultTableModel model = new DefaultTableModel();
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Admin(model).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Button Search;
    private javax.swing.JTextField Search_Bar;
    private javax.swing.JTable attendanceTable;
    private java.awt.Button button1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
